#include "ina219.h"
static I2C_HandleTypeDef *INA219_I2C = NULL;

/* -------------------------------------------------------- */
/* Low-level I2C Register Access                             */
/* -------------------------------------------------------- */

HAL_StatusTypeDef INA219_WriteRegister(uint8_t reg, uint16_t value)
{
    uint8_t data[3];
    data[0] = reg;
    data[1] = (value >> 8) & 0xFF;
    data[2] = value & 0xFF;

    return HAL_I2C_Master_Transmit(INA219_I2C, INA219_ADDRESS, data, 3, HAL_MAX_DELAY);
}

HAL_StatusTypeDef INA219_ReadRegister(uint8_t reg, uint16_t *value)
{
    uint8_t data[2];

    if (HAL_I2C_Master_Transmit(INA219_I2C, INA219_ADDRESS, &reg, 1, HAL_MAX_DELAY) != HAL_OK)
        return HAL_ERROR;

    if (HAL_I2C_Master_Receive(INA219_I2C, INA219_ADDRESS, data, 2, HAL_MAX_DELAY) != HAL_OK)
        return HAL_ERROR;

    *value = (data[0] << 8) | data[1];
    return HAL_OK;
}

/* -------------------------------------------------------- */
/* INA219 Initialization                                     */
/* -------------------------------------------------------- */

void INA219_Init(I2C_HandleTypeDef *hi2c)
{
    INA219_I2C = hi2c;

    uint16_t config =
        (1 << 13) |  // BRNG 32V
        (3 << 11) |  // PG 320mV
        (3 << 7)  |  // BADC 12-bit
        (3 << 3)  |  // SADC 12-bit
        7;           // Mode: continuous

    // Write CONFIG first
    INA219_WriteRegister(INA219_REG_CONFIG, config);

    // Use correct calibration constant (0x6A0B)
    INA219_WriteRegister(INA219_REG_CALIBRATION, INA219_CALIBRATION_VALUE);
}


/* -------------------------------------------------------- */
/* Reading Helper Functions                                  */
/* -------------------------------------------------------- */

float INA219_ReadBusVoltage_V(void)
{
    uint16_t raw;
    INA219_ReadRegister(INA219_REG_BUS_VOLTAGE, &raw);

    raw >>= 3;                     // strip flags
    return raw * 0.004f;           // 4 mV per bit
}

float INA219_ReadShuntVoltage_mV(void)
{
    uint16_t raw;
    INA219_ReadRegister(INA219_REG_SHUNT_VOLTAGE, &raw);

    int16_t sraw = (int16_t)raw;
    return sraw * 0.01f;           // 10 µV -> 0.01 mV per bit
}

float INA219_ReadCurrent_mA(void)
{
    uint16_t raw;
    INA219_ReadRegister(INA219_REG_CURRENT, &raw);

    int16_t sraw = (int16_t)raw;
    float current_A = sraw * CURRENT_LSB;
    return current_A * 1000.0f;     // convert to mA
}

float INA219_ReadPower_mW(void)
{
    uint16_t raw;
    INA219_ReadRegister(INA219_REG_POWER, &raw);

    float power_W = raw * POWER_LSB;
    return power_W * 1000.0f;       // convert to mW
}

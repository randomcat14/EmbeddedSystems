#ifndef INA219_H_
#define INA219_H_

#include "stm32f4xx_hal.h"

/* -------- INA219 DEFAULT I2C ADDRESS -------- */
#define INA219_ADDRESS       (0x40 << 1)

/* -------- INA219 REGISTERS -------- */
#define INA219_REG_CONFIG         0x00
#define INA219_REG_SHUNT_VOLTAGE  0x01
#define INA219_REG_BUS_VOLTAGE    0x02
#define INA219_REG_POWER          0x03
#define INA219_REG_CURRENT        0x04
#define INA219_REG_CALIBRATION    0x05

/* -------- CALIBRATION FOR 0.1 Ω, 0.5 A MAX -------- */
#define INA219_CALIBRATION_VALUE  0x6A0B     // 0x6A0B
#define CURRENT_LSB               0.000015f // 15 µA
#define POWER_LSB                 0.0003f   // 300 µW

/* Public API */
void INA219_Init(I2C_HandleTypeDef *hi2c);

float INA219_ReadBusVoltage_V(void);
float INA219_ReadShuntVoltage_mV(void);
float INA219_ReadCurrent_mA(void);
float INA219_ReadPower_mW(void);

HAL_StatusTypeDef INA219_ReadRegister(uint8_t reg, uint16_t *value);
HAL_StatusTypeDef INA219_WriteRegister(uint8_t reg, uint16_t value);

#endif
